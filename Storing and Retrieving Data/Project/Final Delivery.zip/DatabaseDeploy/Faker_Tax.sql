INSERT INTO `tax` (`id`, `description`, `rate`) VALUES (1, 'Company', 15.0);
INSERT INTO `tax` (`id`, `description`, `rate`) VALUES (2, 'Personal', 23.0);
