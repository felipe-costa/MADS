INSERT INTO `client_category` (`id`, `code`, `description`) VALUES (1, 'LOW_SPENDER', 'People without much spend.');
INSERT INTO `client_category` (`id`, `code`, `description`) VALUES (2, 'MEDIUM_SPENDER', 'People with medium spend.');
INSERT INTO `client_category` (`id`, `code`, `description`) VALUES (3, 'HIGH_SPENDER', 'People with high spend.');
INSERT INTO `client_category` (`id`, `code`, `description`) VALUES (4, 'LAPSED_SPENDER', 'People without purchases in the past 2 months.');
