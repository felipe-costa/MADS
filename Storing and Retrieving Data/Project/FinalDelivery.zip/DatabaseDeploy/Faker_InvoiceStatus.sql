INSERT INTO `invoice_status` (`id`,`description`) VALUES (1, 'PENDING');
INSERT INTO `invoice_status` (`id`,`description`) VALUES (2, 'PAID');
INSERT INTO `invoice_status` (`id`,`description`) VALUES (3, 'CANCELED');
